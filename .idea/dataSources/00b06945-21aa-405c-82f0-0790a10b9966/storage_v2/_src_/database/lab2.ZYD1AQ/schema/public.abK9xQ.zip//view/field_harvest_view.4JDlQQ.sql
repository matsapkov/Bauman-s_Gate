create view field_harvest_view(fieldname, fieldarea, amount, harvest_date) as
SELECT f.fieldname,
       f.fieldarea,
       h.amount,
       h.harvest_date
FROM harvest h
         JOIN fields f ON h.fields_id = f.id;

alter table field_harvest_view
    owner to postgres;

